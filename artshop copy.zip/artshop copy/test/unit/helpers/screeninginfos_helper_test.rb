require 'test_helper'

class ScreeninginfosHelperTest < ActionView::TestCase
end

require 'test_helper'

class OrderitemHelperTest < ActionView::TestCase
end

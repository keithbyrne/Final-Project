require 'test_helper'

class OrdersHelperTest < ActionView::TestCase
end

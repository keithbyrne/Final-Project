require 'test_helper'

class ScreeningroomsHelperTest < ActionView::TestCase
end

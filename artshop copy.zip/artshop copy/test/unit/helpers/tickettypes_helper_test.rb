require 'test_helper'

class TickettypesHelperTest < ActionView::TestCase
end

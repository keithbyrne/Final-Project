require 'test_helper'

class TicketsHelperTest < ActionView::TestCase
end

require 'test_helper'

class ScreeninginfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

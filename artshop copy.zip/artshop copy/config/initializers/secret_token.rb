# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Artshop::Application.config.secret_token = 'd29726a85f12826c1c9a408e8ababf81174286cb8d344bc14556dc5655bf2289af930b179c2a4a07ca4998890ea73fd1fa8e726df13f1444b9bf75ca5d952a49'

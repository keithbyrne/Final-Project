class HomeController < ApplicationController
  def sign_up
  end
end

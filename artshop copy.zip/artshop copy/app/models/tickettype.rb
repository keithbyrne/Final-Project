class Tickettype < ActiveRecord::Base
  attr_accessible :discount, :type
end

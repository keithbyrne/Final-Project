class Screeningroom < ActiveRecord::Base
  attr_accessible :capacity, :name
end
